class storage:
    """Class describing storage properties"""
   Title = "Storage"
postition = [0, 1]
storage_pickup = 1
storage_delivere = 2

   def __init__(self, location):
       self.location=location
