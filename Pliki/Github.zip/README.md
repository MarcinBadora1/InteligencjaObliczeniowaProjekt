# InteligencjaObliczeniowaProjekt
Inteligencja Obliczeniowa UE Katowice -projekt
