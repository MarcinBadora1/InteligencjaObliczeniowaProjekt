import numpy as np
rng = np.random.default_rng(12345)

coords = np.random.rand(rng.integers(low=400, high=600, size=1), 2) * 100

