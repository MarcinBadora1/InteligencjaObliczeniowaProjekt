class Vehicle(object):
    """Class describing vehicle in motion!"""


Title = "Vehicle"


def __init__(self, current_capacity, capacity_left, current_localisation, target):
    assert isinstance(current_capacity, object)
    self.currentcapacity = current_capacity
    self.capacityleft = capacity_left
    self.localisation = current_localisation
    self.targetlocalisation = target


@property
def currentcapacity(self):
    return self.__currentcapacity


@property
def capacityleft(self):
    return self.__capacityleft


@property
def localisation(self):
    return self.__localisation


@property
def targetlocalisation(self):
    return self.__targetlocalisation


@localisation.setter
def localisation(self, a):
    self.__localisation = a


@currentcapacity.setter
def currentcapacity(self, a):
    self.__currentcapacity = a


@capacityleft.setter
def leftcapacity(self, a):
    self.__capacityleft = a


@targetlocalisation.setter
def targetlocalisation(self, a):
    self.__targetlocalisation = a
