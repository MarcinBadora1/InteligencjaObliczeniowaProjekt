class Storage(object):
    """Class describing storage properties"""


Title = "Storage"


def __init__(self, current_location, main_storagepickup, main_storagedelivered):
    self.location = current_location
    self.storagepickup = main_storagepickup
    self.storagedelivered = main_storagedelivered


@property
def location(self):
    return self.__location


@property
def storagepickup(self):
    return self.__storagepickup


@property
def storagedelivered(self):
    return self.__storagedelivered


@location.setter
def location(self, a):
    self.__location = a


@storagepickup.setter
def storagepickup(self, a):
    self.storagepickup = a


@storagedelivered.setter
def storagedelivered(self, a):
    self.storagedelivered = a
