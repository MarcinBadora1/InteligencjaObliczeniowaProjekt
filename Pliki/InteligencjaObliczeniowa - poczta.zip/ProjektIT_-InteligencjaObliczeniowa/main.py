import random

import vehicle
from storage import Storage
from vehicle import Vehicle
import math
import numpy as np
import matplotlib.pyplot as plt


def euclideces_btpoints_distance(x_coordinates_1, x_coordinates_2, y_coordinates_1, y_coordinates_2):
    """Funkcja obliczająca odległość między puntami w układzie =Kartezjansim (dwuwymiarowym)"""
    return math.sqrt(math.pow(x_coordinates_1 - x_coordinates_2, 2) + math.pow(y_coordinates_1 - y_coordinates_2, 2))


rng = np.random.default_rng(12345)

coords = np.random.rand(rng.integers(low=400, high=600, size=1).item(), 2) * 100
print(coords)
x_coordinates = []
y_coordinates = []

for each in coords.tolist():
    x_coordinates.append(each[0])
    y_coordinates.append(each[1])
print(x_coordinates)
print(y_coordinates)
plt.scatter(x=x_coordinates, y=y_coordinates)
plt.title("Generalizacja problemu początkowego")
plt.xlabel("Punkt szerokości geograficznej")
plt.ylabel("Punkt długości geograficznej")
plt.show()
old2 = 0
oldo = 0

lista = [x_coordinates[0], y_coordinates[0]]
storage0 = Storage()
list_of_vehicles = []
for x in range(random.randint(3, 6)):
    list_of_vehicles.append(Vehicle(1000, 0, storage0.localisation, 0))
print(vehicle.capacityleft())
vehicle.capacityleft()

print(list_of_vehicles[0])
print(list_of_vehicles[0].localisation())
